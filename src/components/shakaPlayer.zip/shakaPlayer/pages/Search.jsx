import { PlayerMenu } from "../components/PlayerMenu";
import { Input } from "../components/ui/input";
import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";

const Search = () => {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-stream-background">
      <PlayerMenu />
      <div className="container mx-auto px-4 pt-24">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-stream-text-primary mb-8">Search</h1>
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-stream-text-secondary" />
            <Input
              type="text"
              placeholder="Search for movies, TV shows, actors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 bg-stream-background-lighter border-stream-background-lighter text-stream-text-primary placeholder:text-stream-text-secondary"
            />
          </div>
          {searchQuery && (
            <div className="mt-8 text-center text-stream-text-secondary">
              Search functionality coming soon...
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Search;
