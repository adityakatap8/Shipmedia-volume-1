import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Button } from "../components/ui/button";
import { Play, Info } from "lucide-react";
import { useToast } from "../components/ui/use-toast";
import { PlayerMenu } from "../components/PlayerMenu";
import placeholder from "../../../assets/placeholder.svg"; // Import the placeholder image
import './index.css';

// Function to sanitize the title and create a proper URL for images
const sanitizeTitle = (title) => {
  if (!title) return '';
  // Replace spaces with "+" and remove any special characters
  return title.toLowerCase().replace(/\s+/g, '+').replace(/[^\w+-]/g, '');
};

const MovieDetails = () => {
  const { projectId } = useParams(); // Extract the projectId from URL
  const { toast } = useToast();

  const [isLoading, setIsLoading] = useState(true);
  const [movieData, setMovieData] = useState(null);
  const [error, setError] = useState(null);
  const [isTrailerPlaying, setIsTrailerPlaying] = useState(false); // Manage trailer playback state
  const [trailerUrl, setTrailerUrl] = useState(''); // Store trailer URL

  // Fetching the data
  const fetchMovieData = async () => {
    if (!projectId) {
      setError("Invalid project ID.");
      setIsLoading(false);
      return;
    }

    console.log("Fetching data for projectId:", projectId); // Log the projectId to confirm

    try {
      const response = await axios.get(`http://localhost:3000/api/project-form/data/${projectId}`);
      if (response.status === 200) {
        console.log("Fetched data:", response.data); // Log the response data
        setMovieData(response.data); // Store the fetched movie data
      } else {
        setError("Failed to load data.");
      }
    } catch (error) {
      console.error("Error occurred while fetching data:", error); // Log error for debugging
      setError("An error occurred while fetching the data.");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load project details. Please try again later.",
      });
    } finally {
      setIsLoading(false); // Stop loading indicator once the data is fetched or error is handled
    }
  };

  useEffect(() => {
    // Call fetchMovieData every time the projectId changes
    fetchMovieData();
  }, [projectId]);

  // Show loading state or error message while waiting for data
  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>; // Show error message if there's an error
  }

  if (!movieData) {
    return <div>No data available.</div>; // If movieData is still null after loading, show message
  }

  // Destructure the movieData into required parts
  const { projectInfoData, submitterInfoData, creditsInfoData, specificationsInfoData } = movieData;

  // Sanitize the title to create valid image URLs
  const sanitizedTitle = sanitizeTitle(projectInfoData.projectTitle || "default");
  const backgroundImageURL = projectInfoData.backgroundImage || `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/film+stills/banner.jpg`;
  const logoImageURL = projectInfoData.logoImage || `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/film+stills/logo.jpg`;

  // Trailer URL construction using the sanitized title and the trailer filename
  const trailerVideoURL = `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/trailer/trailer.mp4`;

  // Play Trailer handler
  const handlePlayTrailer = () => {
    setTrailerUrl(trailerVideoURL); // Set the trailer URL dynamically
    setIsTrailerPlaying(true); // Trigger trailer to play
    console.log("Playing trailer from URL:", trailerVideoURL); // Log for debugging
  };

  // Close Trailer handler
  const handleCloseTrailer = () => {
    setIsTrailerPlaying(false); // Stop trailer playback
    setTrailerUrl(''); // Reset trailer URL
  };

  return (
    <div className="min-h-screen bg-stream-background">
      <PlayerMenu />
      {/* Movie Hero Section */}
      <div className="relative h-[80vh] w-full">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${backgroundImageURL})` }} // Updated background image URL
        >
          <div className="absolute inset-0 bg-gradient-to-t from-stream-background via-transparent to-transparent" />
        </div>

        <div className="absolute bottom-0 left-0 w-1/2 pl-10 pt-20">
          <img
            src={logoImageURL}
            alt={projectInfoData.projectTitle}
            className="w-64 mb-6"
            style={{ height: '250px', objectFit: 'contain' }}
          />
          <p className="text-stream-text-primary text-lg mb-4 brief-synopsis">
            {projectInfoData.briefSynopsis}
          </p>
          <div className="flex items-center gap-4 text-stream-text-secondary mb-6">
            <span>{projectInfoData.createdAt.substring(0, 4)}</span>
            <span>{projectInfoData.rating}</span>
            <span>{projectInfoData.genre}</span>
          </div>
          <div className="flex gap-4">
            <Button size="lg" className="bg-white text-black hover:bg-gray-200" onClick={handlePlayTrailer}>
              <Play className="mr-2 h-5 w-5" />
              Play Trailer
            </Button>
            <Button size="lg" variant="secondary">
              <Info className="mr-2 h-5 w-5" />
              Play Movie
            </Button>
          </div>
        </div>
      </div>

      {/* Show Trailer Video when playing */}
      {isTrailerPlaying && trailerUrl && (
        <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-75 flex justify-center items-center">
          <div className="relative">
            <video width="80%" controls autoPlay>
              <source src={trailerUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <button
              onClick={handleCloseTrailer}
              className="absolute top-0 right-0 p-4 text-white text-3xl"
            >
              X
            </button>
          </div>
        </div>
      )}

      {/* Project Information */}
      <div className="container mx-auto px-4 py-12">
        {/* Project Details */}
        <div className="p-6 rounded-lg shadow-lg text-left text-white brief-synopsis">
          <p><strong>Title:</strong> {projectInfoData.projectTitle}</p>
          <p><strong>Website:</strong> <a href={projectInfoData.website} target="_blank" rel="noopener noreferrer">{projectInfoData.website}</a></p>
          <div className="social-links mt-4">
            <a href={projectInfoData.twitter} target="_blank" rel="noopener noreferrer">Twitter</a> | 
            <a href={projectInfoData.facebook} target="_blank" rel="noopener noreferrer">Facebook</a> | 
            <a href={projectInfoData.instagram} target="_blank" rel="noopener noreferrer">Instagram</a>
          </div>
        </div>

        {/* Submitter Information */}
        <div className="mt-2">
          <div className="text-left text-white p-6 rounded-lg shadow-md  brief-synopsis">
            <p><strong>Email:</strong> {submitterInfoData.email}</p>
            <p><strong>Phone:</strong> {submitterInfoData.contactNumber}</p>
            <p><strong>Address:</strong> {submitterInfoData.address}, {submitterInfoData.city}, {submitterInfoData.state}</p>
            <p><strong>Postal Code:</strong> {submitterInfoData.postalCode}</p>
            <p><strong>Country:</strong> {submitterInfoData.country}</p>
          </div>
        </div>

        {/* Credits Information */}
        <div className="mt-2">
          <div className="text-left text-white p-6 rounded-lg shadow-md  brief-synopsis">
            <p><strong>Directors:</strong> {creditsInfoData.directors.map(director => `${director.firstName} ${director.lastName}`).join(", ")}</p>
            <p><strong>Writers:</strong> {creditsInfoData.writers.map(writer => `${writer.firstName} ${writer.lastName}`).join(", ")}</p>
            <p><strong>Producers:</strong> {creditsInfoData.producers.map(producer => `${producer.firstName} ${producer.lastName}`).join(", ")}</p>
          </div>
        </div>

        {/* Specifications Information */}
        <div className="mt-2">
          <div className="text-left text-white p-6 rounded-lg shadow-md  brief-synopsis">
            <p><strong>Project Type:</strong> {specificationsInfoData.projectType}</p>
            <p><strong>Genres:</strong> {specificationsInfoData.genres}</p>
            <p><strong>Completion Date:</strong> {new Date(specificationsInfoData.completionDate).toLocaleDateString()}</p>
            <p><strong>Country of Origin:</strong> {specificationsInfoData.countryOfOrigin}</p>
            <p><strong>Country of Filming:</strong> {specificationsInfoData.countryOfFilming}</p>
            <p><strong>Language:</strong> {specificationsInfoData.language}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;
