import { useState, useEffect } from "react";
import { Play } from "lucide-react";
import { PlayerMenu } from "../components/PlayerMenu.jsx";
import { useToast } from "../components/ui/use-toast.js";
import { useNavigate } from "react-router-dom";
import axios from "axios"; // For API calls
import './index.css';
import { Button } from "../components/ui/button.jsx"; // Adjust the path accordingly


const Showcase = () => {
  const { toast } = useToast();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [projectData, setProjectData] = useState([]); // Store project data fetched from backend
  const [isTrailerPlaying, setIsTrailerPlaying] = useState(false); // State to handle trailer video play
  const [trailerUrl, setTrailerUrl] = useState(''); // To store the trailer URL
  const [isCarouselPaused, setIsCarouselPaused] = useState(false); // Pause carousel when trailer plays
  const navigate = useNavigate(); // Initialize navigate

  // Fetch project data from the backend
  useEffect(() => {
    axios
      .get('http://localhost:3000/api/projects') // Adjusted endpoint
      .then((response) => {
        setProjectData(response.data); // Store project data in state
      })
      .catch((err) => {
        console.error('Error fetching projects:', err);
      });
  }, []);

  // Sanitize the project title for use in the image URL path
  const sanitizeTitle = (title) => {
    if (!title) return '';
    return title.toLowerCase().replace(/\s+/g, '+').replace(/[^\w+-]/g, '');
  };

  // HeroCarousel component to render project data dynamically
  const HeroCarousel = ({ items }) => {
    useEffect(() => {
      if (!items || items.length === 0 || isCarouselPaused) return;

      const timer = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % items.length);
      }, 5000); // Slide every 5 seconds

      return () => clearInterval(timer);
    }, [items.length, isCarouselPaused]);

    const currentItem = items[currentIndex];

    const sanitizedTitle = sanitizeTitle(currentItem?.projectTitle || "default");
    const backgroundImageURL = currentItem?.backgroundImage || `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/film+stills/banner.jpg`;
    const logoImageURL = currentItem?.logoImage || `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/film+stills/logo.jpg`;

    // Trailer URL construction using 'trailer' file name
    const trailerVideoURL = `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/trailer/trailer.mp4`;

    const handlePlayTrailer = () => {
      // Pause the carousel when trailer is played
      setIsCarouselPaused(true);
      setTrailerUrl(trailerVideoURL); // Set the trailer URL dynamically
      setIsTrailerPlaying(true); // Trigger the trailer to be played
      console.log("Playing trailer from URL:", trailerVideoURL); // Log the trailer URL for debugging
    };

    const handlePlayMovie = () => {
      navigate(`/movie/${currentItem._id}`);
    };

    const handleCloseTrailer = () => {
      // Resume the carousel when the trailer is closed
      setIsCarouselPaused(false);
      setIsTrailerPlaying(false); // Stop the trailer
    };

    return (
      <div className="relative h-[80vh] w-full overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url(${backgroundImageURL})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-stream-background via-transparent to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-stream-background via-transparent to-transparent" />
        </div>

        <div className="absolute bottom-0 left-0 pl-10 pt-40 w-1/2 ">
          <img
            src={logoImageURL}
            alt={currentItem?.projectTitle || "Project Logo"}
            className="w-64 mb-6"
            style={{ height: '250px', objectFit: 'contain' }}
          />
          <h3 className="text-white text-3xl font-semibold mb-4">
            {currentItem?.projectTitle || "Untitled Project"}
          </h3>
          <p className="text-stream-text-primary text-lg mb-4 truncate-description brief-synopsis">
            {currentItem?.briefSynopsis || "No description available."}
          </p>

          <div className="flex items-center gap-4 text-stream-text-secondary mb-6">
            <span>{currentItem?.releaseYear || "Unknown Year"}</span>
            <span>{currentItem?.rating || "Unknown Rating"}</span>
            <span>{currentItem?.genre || "Unknown Genre"}</span>
          </div>

          <div className="flex gap-4">
            <Button
              size="lg"
              className="bg-white text-black hover:bg-gray-200"
              onClick={handlePlayTrailer}
            >
              <Play className="mr-2 h-5 w-5" />
              Play Trailer
            </Button>

            <Button
              size="lg"
              className="bg-white text-black hover:bg-gray-200"
              onClick={handlePlayMovie}
            >
              <Play className="mr-2 h-5 w-5" />
              Play Movie
            </Button>
          </div>
        </div>

        {isTrailerPlaying && trailerUrl && (
          <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-75 flex justify-center items-center">
            <div className="relative">
              <video width="80%" controls autoPlay>
                <source src={trailerUrl} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <button
                onClick={handleCloseTrailer}
                className="absolute top-0 right-0 p-4 text-white text-3xl"
              >
                X
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-stream-background">
      <PlayerMenu />
      {projectData.length > 0 && <HeroCarousel items={projectData} />}
      <div className="p-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {projectData.length > 0 && projectData.map((project) => {
            const sanitizedTitle = sanitizeTitle(project?.projectTitle || "default");
            const logoImageURL = project?.logoImage || `https://mediashippers-filestash.s3.eu-north-1.amazonaws.com/${sanitizedTitle}/film+stills/logo.jpg`;

            return (
              <div
                key={project._id}
                className="flex flex-col items-center cursor-pointer"
                onClick={() => navigate(`/movie/${project._id}`)} // Redirect to project details page when the image is clicked
              >
                <img
                  src={logoImageURL}
                  alt={project?.projectTitle || "Project Logo"}
                  className="w-40 h-40 object-contain mb-4"
                />
                <h3 className="text-white text-xl font-semibold mb-2">
                  {project?.projectTitle || "Untitled Project"}
                </h3>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Showcase;
