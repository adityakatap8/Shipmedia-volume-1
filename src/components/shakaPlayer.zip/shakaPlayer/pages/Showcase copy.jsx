import { useState, useEffect } from "react";
import axios from "axios";
import { Button } from "../components/ui/button";
import { Play, Info } from "lucide-react";
import { Menu } from "../components/Menu.jsx";
import { useToast } from "../components/ui/use-toast.js";
import placeholder from "../../../assets/placeholder.svg"; // Imported placeholder image

const Showcase = () => {
  const { toast } = useToast();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentFolder, setCurrentFolder] = useState(""); // Track current folder
  const [folders, setFolders] = useState([]); // List of folders in the current folder
  const [files, setFiles] = useState([]); // List of files in the current folder
  const [isLoading, setIsLoading] = useState(false); // For loading state

  const heroData = {
    "heroItems": [
      {
        "id": "movie_1",
        "title": "Sky Warriors",
        "description": "Elite pilots embark on daring missions in hostile skies.",
        "backgroundImage": placeholder,
        "logoImage": placeholder,
        "genre": "Action",
        "releaseYear": 2021,
        "rating": "PG-13",
        "ctaLink": "/movie/movie_1"
      },
      {
        "id": "series_1",
        "title": "Mystic Falls",
        "description": "A small town shrouded in mystery, where secrets unfold each season.",
        "backgroundImage": placeholder,
        "logoImage": placeholder,
        "genre": "Drama",
        "releaseYear": 2019,
        "rating": "TV-14",
        "ctaLink": "/series/series_1"
      }
    ]
  };

  const HeroCarousel = ({ items }) => {
    useEffect(() => {
      const timer = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % items.length);
      }, 5000);

      return () => clearInterval(timer);
    }, [items.length]);

    const currentItem = items[currentIndex];

    return (
      <div className="relative h-[80vh] w-full overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-700"
          style={{ backgroundImage: `url(${currentItem.backgroundImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-transparent" />
        </div>

        <div className="absolute bottom-0 left-0 p-12 w-1/2">
          <img
            src={currentItem.logoImage}
            alt={currentItem.title}
            className="w-64 mb-6"
          />
          <p className="text-white text-lg mb-4">
            {currentItem.description}
          </p>
          <div className="flex items-center gap-4 text-gray-400 mb-6">
            <span>{currentItem.releaseYear}</span>
            <span>{currentItem.rating}</span>
            <span>{currentItem.genre}</span>
          </div>
          <div className="flex gap-4">
            <Button
              size="lg"
              className="bg-white text-black hover:bg-gray-200"
              onClick={() => (window.location.href = currentItem.ctaLink)}
            >
              <Play className="mr-2 h-5 w-5" />
              Play
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={() => (window.location.href = currentItem.ctaLink)}
            >
              <Info className="mr-2 h-5 w-5" />
              More Info
            </Button>
          </div>
        </div>
      </div>
    );
  };

  // Fetch folder contents (folders and files) from the API
  const fetchFolderContents = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:3000/api/folders/list-folder?folderPath=${currentFolder}`
      );
      setFolders(response.data.folders || []);
      setFiles(response.data.files || []);
    } catch (error) {
      console.error("Error fetching folder contents:", error);
      toast.error("Error fetching folder contents.");
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchFolderContents(); // Re-fetch folder contents when currentFolder changes
  }, [currentFolder]); // Run when currentFolder changes

  // Handle folder item click (Navigate to subfolder)
  const handleFolderClick = (folderName) => {
    const newFolderPath = `${currentFolder}/${folderName}`;
    setCurrentFolder(newFolderPath); // Update current folder
  };

  // Handle file item click (Display file content or info)
  const renderFileItem = (file) => (
    <div key={file.name} className="flex items-center p-4 bg-gray-700 hover:bg-gray-600 rounded cursor-pointer">
      <i className="fas fa-file-alt mr-4 text-gray-400"></i>
      <span className="text-white">{file.name}</span>
    </div>
  );

  // Render folder items
  const renderFolderItem = (folder) => (
    <div
      key={folder.name}
      className="flex items-center p-4 bg-gray-700 hover:bg-gray-600 rounded cursor-pointer"
      onDoubleClick={() => handleFolderClick(folder.name)} // Double-click to navigate into subfolder
    >
      <i className="fas fa-folder mr-4 text-gray-400"></i>
      <span className="text-white">{folder.name}</span>
    </div>
  );

  // Render breadcrumbs
  const renderBreadcrumbs = () => {
    const parts = currentFolder.split('/').filter(Boolean);

    return (
      <div className="flex items-center text-white mb-6">
        <span
          className="cursor-pointer"
          onClick={() => setCurrentFolder('')} // Go back to root folder
        >
          Root
        </span>
        {parts.map((part, index) => (
          <span key={index} className="mx-2">
            {' > '}
            <span
              onClick={() => setCurrentFolder(parts.slice(0, index + 1).join('/'))}
              className="cursor-pointer"
            >
              {part}
            </span>
          </span>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black">
      <Menu />
      {heroData && <HeroCarousel items={heroData.heroItems} />}

      <div className="space-y-4 p-6">
        {renderBreadcrumbs()} {/* Render breadcrumbs here */}

        <div className="folder-view bg-gray-800 p-6 rounded-lg">
          <h3 className="text-white mb-4">Folders</h3>
          <div className="folder-list">
            {isLoading ? (
              <p className="text-white text-lg text-center">Loading Folders...</p>
            ) : (
              folders.map((folder) => renderFolderItem(folder))
            )}
          </div>

          <h3 className="text-white mt-8 mb-4">Files</h3>
          <div className="file-list">
            {isLoading ? (
              <p className="text-white text-lg text-center">Loading Files...</p>
            ) : (
              files.map((file) => renderFileItem(file))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Showcase;
