import React from 'react'
import './CatalogueFestivals.css'
function CatalogueFestivals() {
  return (
    <div>catalogueFestivals</div>
  )
}

export default CatalogueFestivals